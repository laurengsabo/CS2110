/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 screen2 screen2.png 
 * Time-stamp: Wednesday 04/05/2023, 00:38:38
 * 
 * Image Information
 * -----------------
 * screen2.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SCREEN2_H
#define SCREEN2_H

extern const unsigned short screen2[38400];
#define SCREEN2_SIZE 76800
#define SCREEN2_LENGTH 38400
#define SCREEN2_WIDTH 240
#define SCREEN2_HEIGHT 160

#endif

