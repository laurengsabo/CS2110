/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 space space.jpeg 
 * Time-stamp: Wednesday 04/05/2023, 00:45:12
 * 
 * Image Information
 * -----------------
 * space.jpeg 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SPACE_H
#define SPACE_H

extern const unsigned short space[38400];
#define SPACE_SIZE 76800
#define SPACE_LENGTH 38400
#define SPACE_WIDTH 240
#define SPACE_HEIGHT 160

#endif

